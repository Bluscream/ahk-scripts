# ahk-scripts
Collection of Scripts for AutoHotKey
